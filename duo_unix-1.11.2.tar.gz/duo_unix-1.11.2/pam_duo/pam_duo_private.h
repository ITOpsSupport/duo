#include <stdlib.h>
#include <string.h>
#include "util.h"

/* Parses argv to get the configuration file location and the debug mode */
int
parse_argv(const char **config, int argc, const char *argv[]);
